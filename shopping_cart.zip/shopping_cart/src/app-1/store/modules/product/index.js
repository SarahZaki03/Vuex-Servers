
const state = {};

const mutations = {};

const actions = {};

const getters = {};

const productModule = {
  state,
  mutations,
  actions,
  getters
}

export default productModule;
