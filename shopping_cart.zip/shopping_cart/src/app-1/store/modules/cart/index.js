
const state = {};

const mutations = {};

const actions = {};

const getters = {};

const cartModule = {
  state,
  mutations,
  actions,
  getters
}

export default cartModule;
